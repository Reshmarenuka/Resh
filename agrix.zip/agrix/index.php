<!DOCTYPE html>
<html>
<head>
	<title>Sample mailer...</title>
</head>

<style type="text/css">
	

body{

	margin: 100 0;
}


	.form
	{
		height: 300px;
		padding: 30px;
		width: 400px;
		margin:200px 300px;
		background-color: yellow;
		border-radius: 30px;
	}
	.n
	{
		width: 230px;
		height:40px;
		border-radius: 10px;
		text-decoration: none;
		text-align: center;
		color: green;
		font-size: 15px;
	}
	.n1
	{
		width: 230px;
		height:40px;
		border-radius: 10px;
		text-decoration: none;
		text-align: center;
		color: red;
		font-size: 20px;
	}
	.n1:hover
	{
		background-color: red;
		color: white;
	}
	

</style>

<body>


<center>
		<form method="post" class="form" action="send_mail.php">
					<h1 style="color: white;font-size: 30px;">DETAILS</h1>
				<input type="name" name="name" class="n"  placeholder="Name"><br><br>
				<input type="email" name="email" class="n" placeholder="Email"><br><br>
				<input type="submit" name="send" class="n1">

		</form>


</center>
</body>
</html>